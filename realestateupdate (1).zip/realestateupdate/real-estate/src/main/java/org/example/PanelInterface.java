package org.example;


public interface PanelInterface {


    boolean hasSameAmount(RealEstate other);


    int roomprice();
}