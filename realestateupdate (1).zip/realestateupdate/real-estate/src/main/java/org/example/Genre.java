package org.example;

public enum Genre {
    FAMILY_HOUSE,
    CONDOMINIUM,
    FARM
}
