package org.example;


public interface PropertyInterface {


    void makeDiscount(int percent);


    int getTotalPrice();


    double averageSqmPerRoom();


    String toString();
}